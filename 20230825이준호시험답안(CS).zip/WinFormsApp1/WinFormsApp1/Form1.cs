using System;
using System.Windows.Forms;
using System.IO.Ports;
using Microsoft.VisualBasic;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private SerialPort sp = new SerialPort();

        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            Console.Write((cb.SelectedIndex + 1).ToString() + ". ");
            Console.WriteLine(cb.Items[cb.SelectedIndex]);
        }

        private void SerialPort_DataRecv(object sender, SerialDataReceivedEventArgs e)
        {


            // �ø��� �����͸� �о�ɴϴ�.
            string recvData = this.sp.ReadExisting();

            // TextBox ��Ʈ�ѿ� �����͸� �߰��մϴ�.
            AppendReceivedData(recvData);
        }





        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp.PortName = this.comboBox1.Items[comboBox1.SelectedIndex].ToString();
                this.sp.BaudRate = 9600;
                this.sp.DataBits = 8;
                this.sp.StopBits = System.IO.Ports.StopBits.One;
                this.sp.Parity = System.IO.Ports.Parity.None;

                // �ø��� ��Ʈ ����
                this.sp.Open();
                Console.WriteLine("done!");

                // ������ ���� �̺�Ʈ ���
                this.sp.DataReceived += new SerialDataReceivedEventHandler(SerialPort_DataRecv);


                Console.WriteLine("Flag!! 52:");

            }
            catch (Exception ex)
            {
                this.sp.Close();
                Console.WriteLine("failed");
            }
        }

        private void AppendReceivedData(string data)
        {
            Console.WriteLine(data);
        }

        private void led1on_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp.WriteLine("a");
                string response = this.sp.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO ON LED1: " + ex.Message);

            }
        }
        private void led2on_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp.WriteLine("A");
                string response = this.sp.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO ON LED2: " + ex.Message);

            }
        }

        private void led1off_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp.WriteLine("b");
                string response = this.sp.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO OFF LED1: " + ex.Message);

            }
        }

        private void led2off_Click(object sender, EventArgs e)
        {
            try
            {
                this.sp.WriteLine("B");
                string response = this.sp.ReadLine();
                AppendReceivedData(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED TO OFF LED2: " + ex.Message);

            }
        }

    }
}
