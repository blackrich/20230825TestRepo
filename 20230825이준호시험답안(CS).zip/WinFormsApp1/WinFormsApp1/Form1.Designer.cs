﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1 = new ComboBox();
            button1 = new Button();
            led1on = new Button();
            led2on = new Button();
            led1off = new Button();
            led2off = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10", "COM11", "COM12", "COM13" });
            comboBox1.Location = new Point(12, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(150, 23);
            comboBox1.TabIndex = 0;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(168, 12);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Connect";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // led1on
            // 
            led1on.Location = new Point(12, 41);
            led1on.Name = "led1on";
            led1on.Size = new Size(75, 23);
            led1on.TabIndex = 2;
            led1on.Text = "led1 on";
            led1on.UseVisualStyleBackColor = true;
            led1on.Click += led1on_Click;
            // 
            // led2on
            // 
            led2on.Location = new Point(93, 41);
            led2on.Name = "led2on";
            led2on.Size = new Size(75, 23);
            led2on.TabIndex = 3;
            led2on.Text = "led2 on";
            led2on.UseVisualStyleBackColor = true;
            led2on.Click += led2on_Click;
            // 
            // led1off
            // 
            led1off.Location = new Point(12, 70);
            led1off.Name = "led1off";
            led1off.Size = new Size(75, 23);
            led1off.TabIndex = 4;
            led1off.Text = "led1 off";
            led1off.UseVisualStyleBackColor = true;
            led1off.Click += led1off_Click;
            // 
            // led2off
            // 
            led2off.Location = new Point(93, 70);
            led2off.Name = "led2off";
            led2off.Size = new Size(75, 23);
            led2off.TabIndex = 5;
            led2off.Text = "led2 off";
            led2off.UseVisualStyleBackColor = true;
            led2off.Click += led2off_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 96);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 6;
            label1.Text = "Message: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(78, 96);
            label2.Name = "Msg";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 7;
            label2.Text = "";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(255, 428);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(led2off);
            Controls.Add(led1off);
            Controls.Add(led2on);
            Controls.Add(led1on);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private Button button1;
        private Button led1on;
        private Button led2on;
        private Button led1off;
        private Button led2off;
        private Label label1;
        private Label label2;
    }
}